
public interface Item {

	public double getPrice();
	public CarItem.ItemType getType();
}
